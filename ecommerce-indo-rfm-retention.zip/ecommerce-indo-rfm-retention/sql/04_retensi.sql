-- 04_retensi.sql  |  Retensi pelanggan

-- A) Retensi bulanan: pelanggan Juni yang kembali belanja di Juli
WITH aktif AS (SELECT DISTINCT cust_id, strftime('%Y-%m', trx_date) AS bulan FROM trx)
SELECT COUNT(DISTINCT j.cust_id)                                   AS pelanggan_juni,
       COUNT(DISTINCT u.cust_id)                                   AS kembali_di_juli,
       ROUND(100.0 * COUNT(DISTINCT u.cust_id) / COUNT(DISTINCT j.cust_id), 1) AS retensi_pct
FROM aktif j
LEFT JOIN aktif u ON u.cust_id = j.cust_id AND u.bulan = '2022-07'
WHERE j.bulan = '2022-06';

-- B) Pelanggan baru vs kembali di Juli
WITH aktif AS (SELECT DISTINCT cust_id, strftime('%Y-%m', trx_date) AS bulan FROM trx)
SELECT CASE WHEN EXISTS (SELECT 1 FROM aktif j WHERE j.cust_id = u.cust_id AND j.bulan = '2022-06')
            THEN 'Kembali (sudah belanja Juni)' ELSE 'Baru' END AS tipe_pelanggan_juli,
       COUNT(*) AS pelanggan
FROM aktif u
WHERE u.bulan = '2022-07'
GROUP BY 1;

-- C) Kohort mingguan (minggu dimulai hari Senin)
--    date(x, 'weekday 0', '-6 days') = Senin pada minggu tanggal x
WITH minggu AS (
    SELECT DISTINCT cust_id, date(trx_date, 'weekday 0', '-6 days') AS awal_minggu FROM trx
),
kohort AS (SELECT cust_id, MIN(awal_minggu) AS kohort FROM minggu GROUP BY cust_id),
aktif AS (
    SELECT k.kohort,
           CAST((julianday(m.awal_minggu) - julianday(k.kohort)) / 7 AS INTEGER) AS periode,
           COUNT(DISTINCT m.cust_id) AS pelanggan_aktif
    FROM minggu m JOIN kohort k USING (cust_id)
    GROUP BY 1, 2
)
SELECT a.kohort, a.periode, a.pelanggan_aktif,
       ROUND(100.0 * a.pelanggan_aktif /
             (SELECT pelanggan_aktif FROM aktif x WHERE x.kohort = a.kohort AND x.periode = 0), 0) AS retensi_pct
FROM aktif a
ORDER BY a.kohort, a.periode;
