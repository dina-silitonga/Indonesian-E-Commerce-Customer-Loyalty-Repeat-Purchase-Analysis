-- =====================================================================
-- 01_setup_cleaning.sql  |  Kompatibel: SQLite (DB Browser for SQLite, Colab/sqlite3)
-- Tujuan : membuat tabel mentah + VIEW "trx" yang sudah bersih
-- Cara   : import data/raw/repeatbuyer_ecommerce_indo.csv ke tabel raw_trx
--          (DB Browser: File > Import > Table from CSV file... > beri nama raw_trx)
-- =====================================================================

-- Struktur tabel mentah (jika kamu ingin membuatnya manual sebelum import)
CREATE TABLE IF NOT EXISTS raw_trx (
    No           INTEGER,
    Trx_Date     TEXT,      -- format teks: bulan/hari/tahun, contoh 6/1/2022
    Cust_ID      TEXT,
    Age          INTEGER,
    Gender       TEXT,
    AREA         TEXT,
    Product_ID   TEXT,
    Product_Name TEXT,
    Category     TEXT,
    Amount       INTEGER    -- jumlah UNIT, bukan Rupiah
);

DROP VIEW IF EXISTS trx;
CREATE VIEW trx AS
WITH pecah AS (                       -- langkah 1: pecah teks tanggal m/d/yyyy
    SELECT *,
           substr(Trx_Date, 1, instr(Trx_Date, '/') - 1)                         AS m,
           substr(Trx_Date, instr(Trx_Date, '/') + 1)                            AS sisa
    FROM raw_trx
),
pecah2 AS (
    SELECT *,
           substr(sisa, 1, instr(sisa, '/') - 1)                                 AS d,
           substr(sisa, instr(sisa, '/') + 1)                                    AS y
    FROM pecah
)
SELECT
    No                                                    AS no,
    date(printf('%04d-%02d-%02d', y, m, d))               AS trx_date,   -- jadi format ISO yyyy-mm-dd
    Cust_ID                                               AS cust_id,
    Age                                                   AS age,
    Gender                                                AS gender,
    AREA                                                  AS area,
    Product_ID                                            AS product_id,
    Product_Name                                          AS product_name,
    CASE WHEN Category = 'E'                 THEN 'Body Treatment'     -- salah input (Hand Cream HIJ)
         WHEN Category = 'Convinience Goods' THEN 'Convenience Goods'  -- typo
         ELSE Category END                                AS category,
    Amount                                                AS amount
FROM pecah2;

-- Cek cepat: harus 1000 baris, 178 pelanggan, tanggal 2022-06-01 s/d 2022-07-31
SELECT COUNT(*) AS baris, COUNT(DISTINCT cust_id) AS pelanggan,
       MIN(trx_date) AS tgl_awal, MAX(trx_date) AS tgl_akhir
FROM trx;
