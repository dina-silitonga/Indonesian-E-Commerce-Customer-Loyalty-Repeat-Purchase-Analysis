-- 03_rfm.sql  |  Segmentasi RFM (tanggal acuan 2022-08-01)
-- R = hari sejak belanja terakhir | F = jumlah hari belanja | M = total unit
-- NTILE(5) membagi pelanggan menjadi 5 kelompok sama besar (skor 1-5).
-- cust_id dipakai sebagai pemisah jika nilai sama, agar hasil identik dengan Python.

WITH base AS (
    SELECT cust_id,
           MAX(trx_date)               AS last_date,
           COUNT(DISTINCT trx_date)    AS frequency,
           SUM(amount)                 AS monetary
    FROM trx
    GROUP BY cust_id
),
rfm AS (
    SELECT *, CAST(julianday('2022-08-01') - julianday(last_date) AS INTEGER) AS recency
    FROM base
),
skor AS (
    SELECT *,
           NTILE(5) OVER (ORDER BY recency DESC, cust_id)  AS r_score,   -- recency kecil = skor tinggi
           NTILE(5) OVER (ORDER BY frequency,    cust_id)  AS f_score,
           NTILE(5) OVER (ORDER BY monetary,     cust_id)  AS m_score
    FROM rfm
),
gabung AS (
    SELECT *, (f_score + m_score + 1) / 2 AS fm_score      -- pembagian bilangan bulat
    FROM skor
),
segmen AS (
    SELECT *,
           CASE
               WHEN r_score >= 4 AND fm_score >= 4 THEN 'Champions'
               WHEN r_score >= 3 AND fm_score >= 4 THEN 'Loyal'
               WHEN r_score >= 4 AND fm_score >= 2 THEN 'Potential Loyalist'
               WHEN r_score >= 4                   THEN 'Promising'
               WHEN r_score  = 3                   THEN 'Need Attention'
               WHEN fm_score >= 3                  THEN 'At Risk'
               ELSE 'Hibernating'
           END AS segmen
    FROM gabung
)
-- Ringkasan per segmen
SELECT segmen,
       COUNT(*)                                          AS pelanggan,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_pelanggan,
       ROUND(AVG(recency), 1)                            AS rata_recency,
       ROUND(AVG(frequency), 1)                          AS rata_frequency,
       ROUND(AVG(monetary), 1)                           AS rata_unit,
       SUM(monetary)                                     AS total_unit,
       ROUND(100.0 * SUM(monetary) / SUM(SUM(monetary)) OVER (), 1) AS pct_unit
FROM segmen
GROUP BY segmen
ORDER BY pelanggan DESC;

-- Untuk melihat detail per pelanggan, ganti SELECT di atas dengan:
-- SELECT cust_id, recency, frequency, monetary, r_score, f_score, m_score, segmen FROM segmen ORDER BY cust_id;
