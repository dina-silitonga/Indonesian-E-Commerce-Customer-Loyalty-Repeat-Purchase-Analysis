-- 02_kpi_eda.sql  |  KPI & eksplorasi dasar

-- 1) KPI per bulan
SELECT strftime('%Y-%m', trx_date)   AS bulan,
       COUNT(*)                      AS transaksi,
       COUNT(DISTINCT cust_id)       AS pelanggan,
       SUM(amount)                   AS unit
FROM trx
GROUP BY 1
ORDER BY 1;

-- 2) Unit & pelanggan per kategori
SELECT category,
       SUM(amount)                                                         AS unit,
       COUNT(DISTINCT cust_id)                                             AS pelanggan,
       ROUND(100.0 * COUNT(DISTINCT cust_id) /
             (SELECT COUNT(DISTINCT cust_id) FROM trx), 1)                 AS pct_pelanggan
FROM trx
GROUP BY category
ORDER BY unit DESC;

-- 3) Top 10 produk berdasarkan unit
SELECT product_name, category, SUM(amount) AS unit, COUNT(*) AS transaksi
FROM trx
GROUP BY product_name, category
ORDER BY unit DESC
LIMIT 10;

-- 4) Repeat rate: % pelanggan dengan >= 2 hari belanja
WITH f AS (SELECT cust_id, COUNT(DISTINCT trx_date) AS frekuensi FROM trx GROUP BY cust_id)
SELECT COUNT(*)                                             AS total_pelanggan,
       SUM(CASE WHEN frekuensi >= 2 THEN 1 ELSE 0 END)      AS pelanggan_repeat,
       ROUND(100.0 * SUM(CASE WHEN frekuensi >= 2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS repeat_rate_pct
FROM f;

-- 5) Repeat rate per kategori (min. 10 pembeli)
WITH k AS (
    SELECT category, cust_id, COUNT(DISTINCT trx_date) AS kunjungan
    FROM trx GROUP BY category, cust_id
)
SELECT category,
       COUNT(*)                                                    AS pembeli,
       SUM(CASE WHEN kunjungan >= 2 THEN 1 ELSE 0 END)             AS pembeli_ulang,
       ROUND(100.0 * SUM(CASE WHEN kunjungan >= 2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS repeat_rate_pct
FROM k
GROUP BY category
HAVING COUNT(*) >= 10
ORDER BY repeat_rate_pct DESC;

-- 6) Jarak rata-rata antar pembelian (hari)
WITH h AS (SELECT DISTINCT cust_id, trx_date FROM trx),
     g AS (SELECT cust_id,
                  julianday(trx_date) - julianday(LAG(trx_date) OVER (PARTITION BY cust_id ORDER BY trx_date)) AS jarak
           FROM h)
SELECT ROUND(AVG(jarak), 1) AS rata_rata_hari, COUNT(jarak) AS jumlah_selang
FROM g WHERE jarak IS NOT NULL;
