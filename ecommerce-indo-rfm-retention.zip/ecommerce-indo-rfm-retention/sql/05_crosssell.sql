-- 05_crosssell.sql  |  Cross-sell: pasangan kategori yang dibeli pelanggan yang sama
-- support    = % pelanggan yang membeli A dan B
-- confidence = dari pembeli A, % yang juga membeli B
-- lift       = confidence / (% pembeli B)  ->  >1 berarti A dan B saling terkait

WITH cc AS (SELECT DISTINCT cust_id, category FROM trx),
total AS (SELECT COUNT(DISTINCT cust_id) AS n FROM trx),
per_kat AS (SELECT category, COUNT(*) AS c FROM cc GROUP BY category),
pasangan AS (
    SELECT a.category AS dari, b.category AS ke, COUNT(*) AS pelanggan_both
    FROM cc a JOIN cc b ON a.cust_id = b.cust_id AND a.category <> b.category
    GROUP BY a.category, b.category
)
SELECT p.dari, p.ke, p.pelanggan_both,
       ROUND(1.0 * p.pelanggan_both / t.n, 3)                          AS support,
       ROUND(1.0 * p.pelanggan_both / ka.c, 3)                         AS confidence,
       ROUND(1.0 * p.pelanggan_both * t.n / (ka.c * kb.c), 2)          AS lift
FROM pasangan p
JOIN per_kat ka ON ka.category = p.dari
JOIN per_kat kb ON kb.category = p.ke
CROSS JOIN total t
WHERE p.pelanggan_both >= 10
ORDER BY lift DESC, pelanggan_both DESC
LIMIT 15;

-- Penetrasi kategori per segmen: gabungkan hasil segmen RFM (03_rfm.sql) dengan tabel cc
-- (lihat notebooks/02_sql_di_colab.ipynb)
