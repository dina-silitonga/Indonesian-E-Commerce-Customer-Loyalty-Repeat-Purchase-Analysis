# 🛒 Analisis Loyalitas & Pembelian Berulang E-Commerce Indonesia

**Segmentasi RFM · Retensi Pelanggan · Cross-Sell** — proyek analitik data *end-to-end* pada **1.000 transaksi e-commerce Indonesia (Juni–Juli 2022)** menggunakan **Excel, SQL, Python, dan Power BI**.

![Python](https://img.shields.io/badge/Python-pandas%20%7C%20seaborn-3776AB?logo=python&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-SQLite-003B57?logo=sqlite&logoColor=white)
![Excel](https://img.shields.io/badge/Excel-formulas-217346?logo=microsoftexcel&logoColor=white)
![Power BI](https://img.shields.io/badge/Power%20BI-dashboard-F2C811?logo=powerbi&logoColor=black)
[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USERNAME_GITHUB/ecommerce-indo-rfm-retention/blob/main/notebooks/01_analisis_rfm_retensi_crosssell.ipynb)

---

## 🎯 Masalah Bisnis
Sebuah e-commerce ingin tahu: **siapa pelanggan paling berharga, siapa yang mulai pergi, dan produk apa yang bisa dijual silang?** Proyek ini menjawabnya dengan data transaksi 2 bulan.

## ⚡ Temuan Utama

| # | Temuan | Angka |
|---|---|---|
| 1 | **Pelanggan terbaik sangat terkonsentrasi.** *Champions* + *Loyal* hanya 28% pelanggan, tetapi menyumbang **51% unit** terjual | 50 dari 178 pelanggan |
| 2 | **Ada "pelanggan besar yang hilang".** Segmen *At Risk* (22,5% pelanggan) menyumbang **30% unit**, tetapi rata-rata sudah **44 hari** tidak belanja | 40 pelanggan |
| 3 | **Retensi bulanan rendah.** Hanya **28,6%** pelanggan Juni yang kembali di Juli; 73 dari 103 pelanggan Juli adalah pelanggan baru | 30 dari 105 |
| 4 | **Repeat purchase tinggi dalam jangka pendek:** 94% pelanggan belanja ≥ 2 hari berbeda (median 4 kali dalam 2 bulan) | 167 dari 178 |
| 5 | **Repeat rate berbeda jauh antar kategori.** Cosmetics 79%, Body Treatment 60%, Electronics 59% — sedangkan Computer 19% dan Equipments 0% | min. 10 pembeli/kategori |
| 6 | **Cross-sell:** 94% pembeli *Equipments* dan 88% pembeli *Home Appliances* juga membeli *Electronics & Gadget* (lift 2,6 dan 2,4) | n = 15 dan 28 |
| 7 | **4 kategori = 79% unit** (Cosmetics 36%, Electronics 17%, Body Treatment 14%, Hair Treatment 12%) | 1.439 dari 1.820 unit |

> ⚠️ Dataset **tidak memiliki kolom harga**, sehingga `Amount` = **jumlah unit** (bukan Rupiah) dan "Monetary" pada RFM = **total unit**. Lihat bagian [Keterbatasan](#-keterbatasan).

## 📊 Cuplikan Hasil

| Segmentasi RFM | Retensi Kohort Mingguan |
|---|---|
| ![RFM](images/04_rfm_segmen.png) | ![Kohort](images/08_kohort_mingguan.png) |

| Retensi Juni → Juli | Penetrasi Kategori per Segmen |
|---|---|
| ![Retensi](images/07_retensi_bulanan.png) | ![Penetrasi](images/10_penetrasi_segmen.png) |

<details>
<summary>Lihat grafik lainnya</summary>

![Tren](images/01_tren_transaksi.png)
![Kategori](images/02_kategori.png)
![Profil](images/03_profil_pelanggan.png)
![Repeat](images/05_frekuensi_repeat.png)
![Repeat kategori](images/06_repeat_kategori.png)
![Lift](images/09_lift_kategori.png)
</details>

> 🖥️ **Dashboard Power BI:** *(tambahkan screenshot di `images/dashboard_*.png` setelah membangun dashboard — panduan lengkap di [`powerbi/PANDUAN_POWERBI.md`](powerbi/PANDUAN_POWERBI.md))*

## 🧭 Rekomendasi Bisnis

| Segmen | Aksi | Alasan |
|---|---|---|
| **At Risk (40)** | Kampanye *win-back* personal (voucher kategori favorit) | Menyumbang 30% unit tetapi sudah ±44 hari tidak aktif |
| **Champions (36) & Loyal (14)** | Program VIP, akses awal produk, referral | Menyumbang 51% unit |
| **Potential Loyalist (28)** | Voucher "pembelian ke-5", rekomendasi produk lanjutan | Baru aktif, frekuensi masih 3,5 |
| **Pembeli Home Appliances / Equipments** | Tawarkan **Electronics & Gadget** saat checkout / bundling | 88–94% sudah membeli Electronics |
| **Champions** | Dorong **Electronics** (baru 31% yang membeli) dan **Home Appliances** (22%) | Penetrasi rendah pada segmen paling bernilai |
| **Pelanggan baru Juli (73)** | Alur *onboarding* + voucher belanja ke-2 dalam 7 hari | Retensi minggu ke-1 hanya 41–50%, lalu turun tajam |

Detail lengkap: [`insights.md`](insights.md)

## 🧪 Metodologi Singkat
1. **Cleaning** — ubah tanggal ke tipe tanggal, perbaiki kategori salah input (`E` → *Body Treatment*) dan typo (*Convinience*), tentukan kota utama untuk 6 pelanggan yang tercatat di >1 kota, tandai outlier jumlah unit (aturan IQR, tidak dihapus).
2. **RFM** — Recency (hari sejak belanja terakhir, acuan 1 Agu 2022), Frequency (jumlah hari belanja), Monetary (total unit). Skor kuintil 1–5 (`NTILE(5)`), lalu 7 segmen berdasarkan skor R dan rata-rata skor F & M.
3. **Repeat purchase** — repeat buyer = ≥ 2 hari belanja berbeda; jarak antar pembelian; repeat rate per kategori.
4. **Retensi** — retensi bulanan Juni→Juli dan **kohort mingguan** (minggu dimulai Senin).
5. **Cross-sell** — "keranjang" dibentuk per pelanggan; metrik *support, confidence, lift* untuk pasangan kategori dan produk.
6. **Validasi silang** — hasil **Excel (rumus)**, **SQL**, dan **Python** dicocokkan dan identik (mis. 36 Champions, retensi 28,6%).

## 🗂️ Struktur Repositori
```
ecommerce-indo-rfm-retention/
├── README.md
├── insights.md                          # temuan + rekomendasi + KPI pemantauan
├── requirements.txt
├── data/
│   ├── raw/repeatbuyer_ecommerce_indo.csv       # data asli
│   ├── clean/transaksi_clean.csv                # hasil cleaning
│   └── processed/                               # tabel siap pakai untuk Power BI
├── notebooks/
│   ├── 01_analisis_rfm_retensi_crosssell.ipynb  # analisis utama (Python / Colab)
│   └── 02_sql_di_colab.ipynb                    # menjalankan query SQL di Colab
├── sql/                                  # 01 cleaning · 02 KPI · 03 RFM · 04 retensi · 05 cross-sell
├── excel/ecommerce_indo_analisis.xlsx    # workbook berumus (MAXIFS/COUNTIFS/SUMIFS) + grafik
├── powerbi/                              # panduan, ukuran DAX, tema warna
└── images/                               # grafik hasil analisis
```

## ▶️ Cara Menjalankan
**Google Colab (paling mudah):** klik badge *Open in Colab* di atas → *Runtime → Run all*.

**Lokal:**
```bash
git clone https://github.com/USERNAME_GITHUB/ecommerce-indo-rfm-retention.git
cd ecommerce-indo-rfm-retention
pip install -r requirements.txt
jupyter notebook notebooks/01_analisis_rfm_retensi_crosssell.ipynb
```
**SQL:** buka `notebooks/02_sql_di_colab.ipynb`, atau impor CSV ke *DB Browser for SQLite* lalu jalankan file di folder `sql/` berurutan.

## 📖 Kamus Data
| Kolom | Arti |
|---|---|
| `Trx_Date` | Tanggal transaksi (teks `bulan/hari/tahun`) |
| `Cust_ID` | ID pelanggan (178 unik) |
| `Age`, `Gender`, `AREA` | Usia, jenis kelamin, kota |
| `Product_ID`, `Product_Name`, `Category` | Produk (122 unik) dan kategorinya (13 setelah dibersihkan) |
| `Amount` | **Jumlah unit** yang dibeli (bukan Rupiah) |

## ⚠️ Keterbatasan
- **Tanpa harga** → analisis nilai (revenue, CLV, margin) tidak dapat dilakukan; Monetary memakai jumlah unit.
- **Periode hanya 2 bulan** → "tidak muncul di Juli" belum tentu *churn* permanen; tren musiman tidak dapat dinilai.
- **Pola data tidak lazim** → volume harian nyaris konstan (16–17 transaksi/hari, tanpa pola hari/akhir pekan), dan **97% selang antar pembelian (800 dari 822) tepat 1 hari**: pelanggan membeli beruntun harian dalam satu "periode aktif", lalu hilang lama (selang lainnya 8–60 hari). Ini menandakan data kemungkinan **simulasi/sampel**, sehingga median jarak pembelian 1 hari **tidak mencerminkan siklus belanja nyata** dan temuan sebaiknya dibaca sebagai latihan metodologi.
- **Sampel kecil** (178 pelanggan) → aturan cross-sell dengan 10–28 pelanggan sebaiknya diperlakukan sebagai **hipotesis** yang diuji (A/B test), bukan kepastian.
- Segmen RFM bersifat **relatif** (kuintil dalam data ini), bukan ambang absolut.

## 🚀 Pengembangan Lanjutan
- Bandingkan RFM dengan **K-Means clustering**.
- Model prediksi **churn** / kemungkinan pembelian ulang (*logistic regression*, *random forest*).
- Hitung **CLV** dan margin jika data harga tersedia.
- Uji A/B kampanye *win-back* dan *cross-sell* pada segmen terpilih.

## 👤 Penulis
**NAMA KAMU** · [LinkedIn](https://linkedin.com/in/USERNAME) · [GitHub](https://github.com/USERNAME_GITHUB)

*Lisensi: MIT. Data bersifat contoh/pembelajaran.*
