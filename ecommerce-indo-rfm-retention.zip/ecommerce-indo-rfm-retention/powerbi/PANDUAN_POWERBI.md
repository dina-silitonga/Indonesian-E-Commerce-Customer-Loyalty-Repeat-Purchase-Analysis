# 📊 Panduan Membangun Dashboard Power BI (untuk pemula)

Target: dashboard **3 halaman** — *Overview*, *RFM & Segmen*, *Retensi & Cross-Sell*. Estimasi: 1–2 jam.
Butuh **Power BI Desktop** (gratis, Windows). Pengguna Mac bisa memakai Power BI Service (web) atau mesin virtual.

## Langkah 1 — Impor data
`Beranda → Dapatkan data → Teks/CSV`, lalu muat 4 file ini:

| File | Nama tabel (ubah) | Isi |
|---|---|---|
| `data/clean/transaksi_clean.csv` | `transaksi` | 1 baris = 1 transaksi |
| `data/processed/rfm_customers.csv` | `pelanggan_rfm` | 1 baris = 1 pelanggan + skor + **segmen** |
| `data/processed/cohort_weekly.csv` | `kohort` | retensi kohort mingguan |
| `data/processed/crosssell_category_rules.csv` | `crosssell` | aturan A→B, support, confidence, lift |

Di **Power Query** (Transformasi data), pastikan tipe data: `trx_date` = *Tanggal*, `amount`/`frequency`/`monetary`/`recency` = *Bilangan bulat*, `cust_id` = *Teks*, `cohort` = *Tanggal*.

## Langkah 2 — Model data
Buka tampilan **Model**, tarik `pelanggan_rfm[cust_id]` → `transaksi[cust_id]` (relasi **satu-ke-banyak**, arah filter *Single*).
Tabel `kohort` dan `crosssell` berdiri sendiri (tanpa relasi).

## Langkah 3 — Kolom & ukuran DAX
**Urutan segmen** (agar grafik berurut logis). Di tabel `pelanggan_rfm` → *Kolom baru*:
```dax
Urutan Segmen =
SWITCH ( pelanggan_rfm[segmen],
    "Champions", 1, "Loyal", 2, "Potential Loyalist", 3, "Promising", 4,
    "Need Attention", 5, "At Risk", 6, "Hibernating", 7 )
```
Pilih kolom `segmen` → *Urutkan menurut kolom* → `Urutan Segmen`.

**Ukuran (Measures)** — buat di tabel `transaksi` (klik kanan → *Ukuran baru*):
```dax
Total Transaksi   = COUNTROWS ( transaksi )
Total Unit        = SUM ( transaksi[amount] )
Pelanggan Unik    = DISTINCTCOUNT ( transaksi[cust_id] )
Unit per Transaksi = DIVIDE ( [Total Unit], [Total Transaksi] )

Pelanggan Repeat  = CALCULATE ( COUNTROWS ( pelanggan_rfm ), pelanggan_rfm[frequency] >= 2 )
Repeat Rate       = DIVIDE ( [Pelanggan Repeat], COUNTROWS ( pelanggan_rfm ) )

% Unit             = DIVIDE ( [Total Unit], CALCULATE ( [Total Unit], ALLSELECTED () ) )
% Pelanggan        = DIVIDE ( COUNTROWS ( pelanggan_rfm ), CALCULATE ( COUNTROWS ( pelanggan_rfm ), ALLSELECTED () ) )

Pelanggan Juni =
CALCULATE ( DISTINCTCOUNT ( transaksi[cust_id] ), transaksi[bulan] = "2022-06" )

Pelanggan Kembali Juli =
VAR Juni = CALCULATETABLE ( VALUES ( transaksi[cust_id] ), transaksi[bulan] = "2022-06" )
VAR Juli = CALCULATETABLE ( VALUES ( transaksi[cust_id] ), transaksi[bulan] = "2022-07" )
RETURN COUNTROWS ( INTERSECT ( Juni, Juli ) )

Retensi Juni ke Juli = DIVIDE ( [Pelanggan Kembali Juli], [Pelanggan Juni] )
```
Nilai yang harus muncul saat tanpa filter: **1.000 transaksi · 178 pelanggan · 1.820 unit · Repeat Rate 93,8% · Retensi 28,6%**. Jika berbeda, periksa relasi/tipe data.

## Langkah 4 — Susunan halaman
Terapkan tema warna: `Lihat → Tema → Telusuri tema → theme_ecommerce.json`.

### Halaman 1 — Overview
| Posisi | Visual | Isi |
|---|---|---|
| Baris atas | 4 **Kartu** | Total Transaksi, Pelanggan Unik, Total Unit, Repeat Rate |
| Kiri tengah | **Diagram garis** | Sumbu X `trx_date`, Y `Total Transaksi` |
| Kanan tengah | **Diagram batang horizontal** | `category` × `Total Unit` (urut menurun) |
| Bawah | **Diagram donat** + **batang** | Gender (pelanggan unik) & `age_group` |
| Kiri | **Slicer** | `bulan`, `gender`, `area_utama` |

### Halaman 2 — RFM & Segmen
| Visual | Isi |
|---|---|
| **Diagram batang** | `segmen` × `% Pelanggan` dan `% Unit` (dua ukuran) |
| **Diagram sebar** | X = `recency`, Y = `frequency`, Ukuran = `monetary`, Legenda = `segmen` |
| **Tabel** | `cust_id`, `segmen`, `recency`, `frequency`, `monetary`, `area_utama` (urut `monetary` menurun) |
| **Slicer** | `segmen` (klik segmen → semua visual terfilter; berguna untuk daftar target kampanye) |
| **Kartu** | Pelanggan di segmen terpilih |

### Halaman 3 — Retensi & Cross-Sell
| Visual | Isi |
|---|---|
| Kartu | `Pelanggan Juni`, `Pelanggan Kembali Juli`, `Retensi Juni ke Juli` |
| **Matriks** (heatmap) | Baris `kohort`, Kolom `periode`, Nilai `retensi_pct` → *Format → Warna sel → Skala gradien* |
| **Tabel** | Dari `crosssell`: `dari`, `ke`, `pelanggan_both`, `confidence`, `lift` (urut `lift`) |
| **Matriks** | Baris `segmen`, Kolom `category`, Nilai `% pelanggan` → penetrasi kategori per segmen |

## Langkah 5 — Finishing (yang dilihat perekrut)
- Beri **judul & subjudul** jelas di tiap halaman, mis. "Segmen mana yang layak diprioritaskan?".
- Tambahkan **kotak teks insight** (mis. "At Risk = 22,5% pelanggan tetapi 30% unit").
- Konsisten: font, warna segmen sama di semua grafik, nama sumbu dalam Bahasa Indonesia.
- Tambah **catatan**: "Amount = jumlah unit, bukan Rupiah".
- Simpan sebagai `powerbi/ecommerce_dashboard.pbix`, lalu ambil **screenshot tiap halaman** → simpan ke `images/dashboard_1.png`, `dashboard_2.png`, `dashboard_3.png` dan tampilkan di README.
- Opsional: *Berkas → Publikasikan ke web* untuk tautan interaktif (hati-hati: data menjadi publik).

## Masalah umum
| Gejala | Solusi |
|---|---|
| Angka ganda / terlalu besar | Cek relasi: harus satu-ke-banyak dari `pelanggan_rfm` ke `transaksi` |
| Tanggal tampil sebagai teks | Ubah tipe kolom di Power Query ke *Tanggal* |
| Urutan segmen acak | Atur *Urutkan menurut kolom* → `Urutan Segmen` |
| Persentase tampil 0,938 | Pilih ukuran → *Format ukuran* → Persentase |
