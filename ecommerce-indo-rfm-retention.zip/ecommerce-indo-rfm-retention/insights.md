# 💡 Insight & Rekomendasi

## Ringkasan eksekutif
Dari 178 pelanggan (1.000 transaksi, 1.820 unit, Juni–Juli 2022), bisnis ini punya **basis pelanggan yang sering membeli tetapi sulit dipertahankan antar-bulan**: 94% pelanggan belanja ≥ 2 kali, namun hanya **28,6%** pelanggan Juni yang kembali di Juli.

## 1. Segmentasi RFM
| Segmen | Pelanggan | % Pelanggan | % Unit | Rata-rata recency (hari) | Rata-rata frekuensi |
|---|---|---|---|---|---|
| Champions | 36 | 20,2% | 35,4% | 7,1 | 8,9 |
| Loyal | 14 | 7,9% | 15,8% | 24,9 | 10,9 |
| Potential Loyalist | 28 | 15,7% | 8,6% | 8,1 | 3,5 |
| Promising | 6 | 3,4% | 0,5% | 5,7 | 1,3 |
| Need Attention | 22 | 12,4% | 4,9% | 25,2 | 3,2 |
| At Risk | 40 | 22,5% | 30,1% | 43,9 | 7,1 |
| Hibernating | 32 | 18,0% | 4,8% | 45,7 | 2,0 |

**Poin penting:** *At Risk* adalah segmen terbesar dan menyumbang 30% unit — frekuensi rata-rata 7,1 menunjukkan mereka dulu pelanggan aktif. Inilah prioritas *win-back* nomor 1 (potensi pemulihan terbesar per pelanggan).

## 2. Repeat purchase
- Repeat rate 93,8%; median 4 transaksi/pelanggan (maks. 26).
- ⚠️ 97% selang antar pembelian (800 dari 822) tepat 1 hari — pelanggan belanja beruntun harian dalam satu periode aktif, lalu hilang 8–60 hari. Pola ini tidak lazim untuk data riil, jadi "repeat rate" tinggi di sini terutama mencerminkan *beruntunnya* pembelian, bukan kebiasaan belanja berkala.
- Repeat rate per kategori: Cosmetics 78,6% → Body Treatment 60,0% → Electronics 59,4% → Hair Treatment 47,4% → Fashion 30,0% → … → Computer 19,2% → Equipments 0%.
- Kategori kosmetik/perawatan adalah **produk "kebiasaan"** (dibeli berulang); elektronik besar/komputer lebih bersifat pembelian sekali waktu — strategi retensinya harus berbeda (isi ulang vs. aksesori/servis).

## 3. Retensi
- Bulanan: 30 dari 105 pelanggan Juni kembali di Juli (28,6%); 75 hanya Juni; 73 pelanggan Juli adalah pelanggan baru.
- Kohort mingguan: sekitar **41–50%** pelanggan kembali pada minggu berikutnya (kohort 18 Jul: 62%), lalu turun menjadi **5–24%** di minggu ke-2. Peluang terbesar ada pada **7–14 hari pertama** setelah pembelian pertama.
- Hal yang perlu diselidiki: kohort 30 Mei menunjukkan lonjakan kembali (13 dari 30 pelanggan) pada minggu ke-8 (akhir Juli). Perlu data lebih panjang untuk memastikan apakah ini pola akhir bulan atau kebetulan.

## 4. Cross-sell
| Dari → Ke | Pelanggan | Confidence | Lift |
|---|---|---|---|
| Equipments → Electronics & Gadget | 15 | 94% | 2,61 |
| Home Appliances → Electronics & Gadget | 28 | 88% | 2,43 |
| Convenience Goods → Electronics & Gadget | 18 | 86% | 2,38 |
| Computer ↔ Convenience Goods | 11 | 42% / 52% | 3,59 |
| Fashion ↔ Kitchen Appliances | 10 | 50% / 40% | 3,56 |
| Hair Treatment → Cosmetics | 55 | 96% | 1,75 |
| Body Treatment → Cosmetics | 62 | 95% | 1,73 |

*Catatan: lift Cosmetics tidak bisa tinggi karena 55% pelanggan sudah membeli Cosmetics. Pasangan dengan n kecil (10–18) = hipotesis.*

Peluang per segmen (penetrasi kategori): hanya **31%** Champions membeli Electronics dan **22%** membeli Home Appliances → target *cross-sell* utama.

## 5. Rencana aksi & KPI pemantauan
| Inisiatif | Target segmen | KPI |
|---|---|---|
| Win-back dengan voucher kategori favorit | At Risk, Need Attention | % reaktivasi dalam 14 hari |
| Voucher belanja ke-2 dalam 7 hari | Pelanggan baru | Retensi minggu ke-1 (saat ini 41–50%) |
| Rekomendasi Electronics saat checkout | Pembeli Home Appliances/Equipments/Convenience | Attach rate Electronics |
| Program VIP & referral | Champions, Loyal | Frekuensi & unit per pelanggan |

*Semua rekomendasi sebaiknya divalidasi dengan A/B test sebelum diskalakan.*
